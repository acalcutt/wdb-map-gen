/*
Package cache implements caches for coords, nodes, ways and relations data.
*/
package cache
