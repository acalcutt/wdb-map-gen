/*
Package stats provides functions to collect statistics about the import process.
*/
package stats
