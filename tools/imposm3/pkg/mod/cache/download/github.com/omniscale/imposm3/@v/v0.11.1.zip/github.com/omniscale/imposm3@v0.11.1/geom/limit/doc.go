/*
Package limit provides functions to clip geometries at polygon boundaries.
*/
package limit
