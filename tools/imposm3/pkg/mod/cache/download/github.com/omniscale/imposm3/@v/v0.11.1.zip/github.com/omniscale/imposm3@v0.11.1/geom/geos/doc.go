/*
Package geos provides a wrapper to the GEOS library.
*/
package geos
