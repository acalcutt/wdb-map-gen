/*
Package diff provides the diff sub command for updating with diff files.
*/
package update
