// Package diff provides functions for downloading OSM diff files.
package diff
