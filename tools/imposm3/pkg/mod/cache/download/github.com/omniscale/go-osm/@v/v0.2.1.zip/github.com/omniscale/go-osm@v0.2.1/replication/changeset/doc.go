// Package changeset provides functions for downloading OSM changeset files.
package changeset
