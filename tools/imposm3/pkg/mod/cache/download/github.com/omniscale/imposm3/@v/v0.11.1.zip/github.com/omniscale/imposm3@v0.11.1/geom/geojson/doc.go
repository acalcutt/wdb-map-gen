/*
Package geojson creates GEOS geometries from GeoJSON files.
*/
package geojson
