/*
Package changeset provides a parser for OSM changeset files.
*/
package changeset
