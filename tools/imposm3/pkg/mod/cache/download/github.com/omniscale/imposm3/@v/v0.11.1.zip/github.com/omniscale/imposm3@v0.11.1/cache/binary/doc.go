/*
Package binary provides functions for (un)marshaling cache data.
*/
package binary
