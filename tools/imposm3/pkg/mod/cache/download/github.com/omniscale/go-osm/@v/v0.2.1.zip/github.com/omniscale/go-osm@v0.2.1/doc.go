/*
Package osm provides basic types for OSM elements (nodes/ways/relations/etc).
*/
package osm
