/*
Package geom provides functions for building geometries.
*/
package geom
