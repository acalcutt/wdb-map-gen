/*
Package query provides the query-cache sub command for debugging and testing.
*/
package query
