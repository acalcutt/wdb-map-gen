/*
Package test provides system tests for Imposm3.
*/
package test
