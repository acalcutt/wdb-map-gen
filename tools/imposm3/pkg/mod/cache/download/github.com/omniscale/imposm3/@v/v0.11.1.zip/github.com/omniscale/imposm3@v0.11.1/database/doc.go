/*
Package database defines interfaces to be implemented.
*/
package database
