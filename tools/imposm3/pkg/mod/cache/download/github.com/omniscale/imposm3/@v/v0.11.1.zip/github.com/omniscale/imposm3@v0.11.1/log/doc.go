/*
Package log provides a simple framework for reporting messages and the import progress.
*/
package log
