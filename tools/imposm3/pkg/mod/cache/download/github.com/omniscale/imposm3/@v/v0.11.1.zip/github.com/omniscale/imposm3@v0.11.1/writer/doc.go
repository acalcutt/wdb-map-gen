/*
Package writer orchestrates the writing part of the import process.
*/
package writer
