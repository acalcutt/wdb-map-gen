package imposm3

// Version gets replaced while building with
// go build -ldflags "-X github.com/omniscale/imposm3.Version 1.2.3"
var Version = "0.0.0-dev"
