/*
Package element provides basic types for OSM elements (coords/nodes/ways/relations/etc).
*/
package element
