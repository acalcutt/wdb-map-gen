/*
Package state provides functions for reading and writing diff status files.
*/
package state
