// Package replication provides basic types for replication of OSM data.
package replication
