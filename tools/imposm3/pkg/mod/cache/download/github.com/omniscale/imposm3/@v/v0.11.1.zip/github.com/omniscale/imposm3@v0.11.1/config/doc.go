/*
Package config provides functions for parsing command line args and JSON config.
*/
package config
