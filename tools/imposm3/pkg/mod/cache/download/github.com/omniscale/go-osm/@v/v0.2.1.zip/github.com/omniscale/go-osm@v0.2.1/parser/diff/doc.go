/*
Package diff provides a parser for OSM diff files (.osc).
*/
package diff
